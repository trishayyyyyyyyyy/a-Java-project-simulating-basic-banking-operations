package bank.bank.operations;

public class Account implements BankOperations {

 String accountHolder;
 double balance;

 public Account(String accountHolder, double initialbalance){
     this.accountHolder = accountHolder;
     this.balance = initialbalance;
 }
 @Override
 public void deposit(double amount) {
     if (amount > 0) {
         balance += amount;
         System.out.println("Deposited: " + amount);
     } else {
         System.out.println("Deposit more, too low");
     }
 }
    @Override
    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount > balance) {
            throw new InsufficientFundsException("Insufficient funds.");
        }
        balance -= amount;
        System.out.println("Withdrew: " + amount);
    }

    public void displayBalance() {
        System.out.println("Current balance: " + balance);
    }


}
